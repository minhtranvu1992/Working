﻿INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ABSOLUTE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ACTION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ADA')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ADD')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ADMIN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'AFTER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'AGGREGATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ALIAS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ALL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ALLOCATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ALTER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'AND')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ANY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ARE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ARRAY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'AS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ASC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ASENSITIVE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ASSERTION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ASYMMETRIC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'AT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ATOMIC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'AUTHORIZATION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'AVG')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BACKUP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BEFORE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BEGIN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BETWEEN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BINARY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BIT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BIT_LENGTH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BLOB')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BOOLEAN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BOTH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BREADTH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BREAK')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BROWSE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BULK')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'BY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CALL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CALLED')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CARDINALITY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CASCADE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CASCADED')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CASE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CAST')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CATALOG')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CHAR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CHAR_LENGTH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CHARACTER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CHARACTER_LENGTH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CHECK')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CHECKPOINT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CLASS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CLOB')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CLOSE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CLUSTERED')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'COALESCE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'COLLATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'COLLATION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'COLLECT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'COLUMN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'COMMIT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'COMPLETION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'COMPUTE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CONDITION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CONNECT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CONNECTION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CONSTRAINT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CONSTRAINTS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CONSTRUCTOR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CONTAINS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CONTAINSTABLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CONTINUE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CONVERT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CORR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CORRESPONDING')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'COUNT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'COVAR_POP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'COVAR_SAMP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CREATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CROSS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CUBE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CUME_DIST')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CURRENT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CURRENT_CATALOG')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CURRENT_DATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CURRENT_DEFAULT_TRANSFORM_GROUP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CURRENT_PATH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CURRENT_ROLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CURRENT_SCHEMA')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CURRENT_TIME')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CURRENT_TIMESTAMP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CURRENT_TRANSFORM_GROUP_FOR_TYPE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CURRENT_USER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CURSOR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'CYCLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DATA')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DATABASE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DAY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DBCC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DEALLOCATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DEC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DECIMAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DECLARE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DEFAULT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DEFERRABLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DEFERRED')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DELETE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DENY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DEPTH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DEREF')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DESC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DESCRIBE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DESCRIPTOR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DESTROY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DESTRUCTOR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DETERMINISTIC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DIAGNOSTICS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DICTIONARY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DISCONNECT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DISK')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DISTINCT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DISTRIBUTED')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DOMAIN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DOUBLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DROP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DUMP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'DYNAMIC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'EACH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ELEMENT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ELSE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'END')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'END-EXEC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'EQUALS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ERRLVL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ESCAPE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'EVERY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'EXCEPT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'EXCEPTION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'EXEC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'EXECUTE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'EXISTS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'EXIT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'EXTERNAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'EXTRACT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FALSE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FETCH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FILE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FILLFACTOR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FILTER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FIRST')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FLOAT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FOR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FOREIGN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FORTRAN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FOUND')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FREE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FREETEXT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FREETEXTTABLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FROM')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FULL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FULLTEXTTABLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FUNCTION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'FUSION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'GENERAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'GET')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'GLOBAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'GO')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'GOTO')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'GRANT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'GROUP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'GROUPING')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'HAVING')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'HOLD')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'HOLDLOCK')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'HOST')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'HOUR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'IDENTITY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'IDENTITY_INSERT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'IDENTITYCOL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'IF')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'IGNORE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'IMMEDIATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'IN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INCLUDE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INDEX')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INDICATOR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INITIALIZE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INITIALLY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INNER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INOUT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INPUT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INSENSITIVE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INSERT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INTEGER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INTERSECT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INTERSECTION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INTERVAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'INTO')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'IS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ISOLATION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ITERATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'JOIN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'KEY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'KILL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LANGUAGE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LARGE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LAST')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LATERAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LEADING')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LEFT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LESS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LEVEL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LIKE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LIKE_REGEX')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LIMIT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LINENO')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LOAD')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LOCAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LOCALTIME')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LOCALTIMESTAMP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LOCATOR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'LOWER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MAP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MATCH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MAX')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MEMBER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MERGE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'METHOD')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MIN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MINUTE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MOD')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MODIFIES')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MODIFY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MODULE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MONTH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'MULTISET')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NAMES')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NATIONAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NATURAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NCHAR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NCLOB')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NEW')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NEXT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NO')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NOCHECK')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NONCLUSTERED')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NONE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NORMALIZE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NOT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NULL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NULLIF')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'NUMERIC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OBJECT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OCCURRENCES_REGEX')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OCTET_LENGTH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OF')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OFF')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OFFSETS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OLD')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ON')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ONLY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OPEN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OPENDATASOURCE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OPENQUERY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OPENROWSET')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OPENXML')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OPERATION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OPTION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ORDER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ORDINALITY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OUT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OUTER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OUTPUT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OVER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OVERLAPS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'OVERLAY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PAD')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PARAMETER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PARAMETERS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PARTIAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PARTITION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PASCAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PATH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PERCENT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PERCENT_RANK')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PERCENTILE_CONT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PERCENTILE_DISC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PIVOT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PLAN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'POSITION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'POSITION_REGEX')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'POSTFIX')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PRECISION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PREFIX')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PREORDER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PREPARE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PRESERVE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PRIMARY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PRINT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PRIOR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PRIVILEGES')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PROC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PROCEDURE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'PUBLIC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RAISERROR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RANGE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'READ')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'READS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'READTEXT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RECONFIGURE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RECURSIVE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REF')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REFERENCES')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REFERENCING')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REGR_AVGX')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REGR_AVGY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REGR_COUNT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REGR_INTERCEPT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REGR_R2')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REGR_SLOPE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REGR_SXX')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REGR_SXY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REGR_SYY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RELATIVE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RELEASE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REPLICATION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RESTORE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RESTRICT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RESULT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RETURN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RETURNS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REVERT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'REVOKE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RIGHT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ROLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ROLLBACK')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ROLLUP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ROUTINE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ROW')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ROWCOUNT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ROWGUIDCOL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ROWS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'RULE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SAVE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SAVEPOINT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SCHEMA')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SCOPE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SCROLL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SEARCH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SECOND')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SECTION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SECURITYAUDIT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SELECT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SEMANTICKEYPHRASETABLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SEMANTICSIMILARITYDETAILSTABLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SEMANTICSIMILARITYTABLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SENSITIVE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SEQUENCE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SESSION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SESSION_USER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SET')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SETS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SETUSER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SHUTDOWN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SIMILAR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SIZE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SMALLINT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SOME')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SPACE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SPECIFIC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SPECIFICTYPE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SQL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SQLCA')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SQLCODE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SQLERROR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SQLEXCEPTION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SQLSTATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SQLWARNING')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'START')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'STATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'STATEMENT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'STATIC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'STATISTICS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'STDDEV_POP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'STDDEV_SAMP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'STRUCTURE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SUBMULTISET')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SUBSTRING')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SUBSTRING_REGEX')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SUM')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SYMMETRIC')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SYSTEM')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'SYSTEM_USER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TABLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TABLESAMPLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TEMPORARY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TERMINATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TEXTSIZE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'THAN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'THEN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TIME')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TIMESTAMP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TIMEZONE_HOUR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TIMEZONE_MINUTE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TO')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TOP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TRAILING')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TRAN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TRANSACTION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TRANSLATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TRANSLATE_REGEX')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TRANSLATION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TREAT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TRIGGER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TRIM')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TRUE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TRUNCATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TRY_CONVERT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'TSEQUAL')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'UESCAPE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'UNDER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'UNION')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'UNIQUE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'UNKNOWN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'UNNEST')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'UNPIVOT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'UPDATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'UPDATETEXT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'UPPER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'USAGE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'USE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'USER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'USING')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'VALUE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'VALUES')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'VAR_POP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'VAR_SAMP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'VARCHAR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'VARIABLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'VARYING')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'VIEW')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WAITFOR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WHEN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WHENEVER')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WHERE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WHILE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WIDTH_BUCKET')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WINDOW')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WITH')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WITHIN')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WITHIN GROUP')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WITHOUT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WORK')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WRITE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'WRITETEXT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLAGG')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLATTRIBUTES')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLBINARY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLCAST')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLCOMMENT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLCONCAT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLDOCUMENT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLELEMENT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLEXISTS')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLFOREST')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLITERATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLNAMESPACES')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLPARSE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLPI')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLQUERY')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLSERIALIZE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLTABLE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLTEXT')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'XMLVALIDATE')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'YEAR')
GO
INSERT [dbo].[KeyWordList] ([KeyWord]) VALUES (N'ZONE')
GO
