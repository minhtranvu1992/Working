﻿GRANT EXECUTE TO [db_executor]
    AS [dbo];

