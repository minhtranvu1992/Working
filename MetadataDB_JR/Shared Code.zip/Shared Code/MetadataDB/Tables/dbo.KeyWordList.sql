﻿CREATE TABLE [dbo].[KeyWordList] (
    [KeyWord] VARCHAR (100) NULL
);

