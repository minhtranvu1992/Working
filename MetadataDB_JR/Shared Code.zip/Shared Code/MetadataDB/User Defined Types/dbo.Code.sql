﻿CREATE TYPE [dbo].[Code]
    FROM VARCHAR (40) NULL;

