﻿CREATE TYPE [dbo].[Logic]
    FROM VARCHAR (MAX) NULL;



