﻿CREATE TYPE [dbo].[ElementName]
    FROM VARCHAR (100) NULL;

