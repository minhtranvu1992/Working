﻿CREATE TYPE [dbo].[Flag]
    FROM BIT NULL;

