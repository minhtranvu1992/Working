﻿CREATE TYPE [dbo].[ElementOrder]
    FROM INT NULL;

