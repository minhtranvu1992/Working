﻿CREATE TYPE [dbo].[Description]
    FROM VARCHAR (4000) NULL;

