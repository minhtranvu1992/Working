﻿CREATE TYPE [dbo].[ForeignID]
    FROM INT NULL;

