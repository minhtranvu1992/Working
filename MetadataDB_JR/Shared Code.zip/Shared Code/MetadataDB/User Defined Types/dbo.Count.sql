﻿CREATE TYPE [dbo].[Count]
    FROM INT NULL;

