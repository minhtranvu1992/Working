﻿CREATE TYPE [dbo].[PrimaryID]
    FROM INT NOT NULL;

