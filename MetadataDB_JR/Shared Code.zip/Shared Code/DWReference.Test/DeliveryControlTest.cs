﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DWReference.Test
{
    [TestClass]
    public class DeliveryControlTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
