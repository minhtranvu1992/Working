﻿CREATE ROLE [db_executor]
    AUTHORIZATION [dbo];

