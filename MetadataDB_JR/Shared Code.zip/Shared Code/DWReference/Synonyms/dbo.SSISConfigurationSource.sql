﻿CREATE SYNONYM [dbo].[SSISConfigurationSource] FOR [DWReferenceConfiguration].[dbo].[SSISConfiguration];

